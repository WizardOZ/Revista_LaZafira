/*
 var campo = document.getElementByID("idCampo") -- Obtiene una referencia al elemento HTML cuyo id es "idCampo"
 var otroElemento = document.querySelector("otraEtiqueta") -- Obtiene una referencia al elemento HTML cuya etiqueta es <otraEtiqueta>
 var elemento = document.createElement("etiqueta") -- Crea una etiqueta <etiqueta></etiqueta> y la asigna a una variable elemento.
 elemento.setAttribute("attr", "valor") -- incluye en la etiqueta el atributo "attr" con el valor "valor" <etiqueta attr="valor"></etiqueta>
 elemento.innerHTML = "contenido" -- añade contenido dentro la etiqueta <etiqueta attr="valor">contenido</etiqueta>
 otroElemento.appendChild(elemento) -- Añade como hijo el elemento pasado como parámetro:
	 <otraEtiqueta>
	 	<etiqueta attr="valor">contenido</etiqueta>
	 </otraEtiqueta>

 Los id de los campo de los que sacar los datos son: filas, columnas
 */
function miFuncion() {
	var tabla=document.getElementById("mitabla")
	var numeroFilas= parseInt(document.getElementById("filas").value,10)
	var numeroColumnas= parseInt(document.getElementById("columnas").value,10)

	for (var i = 0; i < numeroFilas; i++) {
		var nuevaFila= document.createElement("tr")

		for (var j = 0; j < numeroColumnas; j++) {
			var nuevaColumna=document.createElement("td")

			nuevaColumna.textContent="Fila: "+(1+i)+", Columna: "+(j+1)
			nuevaFila.appendChild(nuevaColumna)
		}
		tabla.appendChild(nuevaFila)
	}
}